#include <stdio.h>

int main() {
    char palavra[100];
    printf("Digite uma palavra: ");
    scanf("%s", palavra);

    int inicio = 0;
    int fim = 0;

    while (palavra[fim] != '\0') {
        fim++;
    }
    fim--; 

    int palindromo = 1; 

    while (inicio < fim) {
        if (palavra[inicio] != palavra[fim]) {
            palindromo = 0;
            break;
        }
        inicio++;
        fim--;
    }

    if (palindromo)
        printf("Eh um palindromo!\n");
    else
        printf("Nao eh um palindromo.\n");

    return 0;
}